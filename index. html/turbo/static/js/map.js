
// Initialize Leaflet map centered on Zarzal, Valle (lat:4.3946, lon:-76.0702)
document.addEventListener('DOMContentLoaded', function(){
  try{
    var map = L.map('map').setView([4.3946, -76.0702], 14);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);
    L.marker([4.3946, -76.0702]).addTo(map).bindPopup('Zarzal, Valle del Cauca').openPopup();
  }catch(e){
    console.error('Leaflet map init error:', e);
  }
});
