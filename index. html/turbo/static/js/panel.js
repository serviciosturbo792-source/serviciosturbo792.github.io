
// Panel open/close logic and WhatsApp link
document.addEventListener('DOMContentLoaded', function(){
  var openBtn = document.getElementById('open-panel-btn');
  var panel = document.getElementById('side-panel');
  var closeBtn = document.getElementById('close-panel');
  var overlay = document.getElementById('overlay');
  var form = document.getElementById('confirm-form');

  function openPanel(){
    panel.classList.add('open');
    overlay.classList.add('visible');
    panel.setAttribute('aria-hidden','false');
    overlay.setAttribute('aria-hidden','false');
  }
  function closePanel(){
    panel.classList.remove('open');
    overlay.classList.remove('visible');
    panel.setAttribute('aria-hidden','true');
    overlay.setAttribute('aria-hidden','true');
  }

  openBtn && openBtn.addEventListener('click', openPanel);
  closeBtn && closeBtn.addEventListener('click', closePanel);
  overlay && overlay.addEventListener('click', closePanel);

  // Build WhatsApp URL and open in new tab/window
  window.openWhatsApp = function(){
    var origin = document.getElementById('origin').value.trim();
    var dest = document.getElementById('destination').value.trim();
    if(!origin || !dest){
      alert('Por favor completa ambos campos.');
      return false;
    }
    var user = typeof user_email !== 'undefined' ? user_email : '';
    var text = 'Hola, ';
    if(user){
      text += 'soy ' + user + ', ';
    }
    text += 'quiero confirmar un viaje desde ' + origin + ' hasta ' + dest + '.';
    // encode
    var encoded = encodeURIComponent(text);
    var wa = 'https://wa.me/573180237489?text=' + encoded;
    // open in new window/tab; on mobile it will open the app
    window.open(wa, '_blank');
    // close panel
    closePanel();
    return false; // prevent form submit
  };
});
