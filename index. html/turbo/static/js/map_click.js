
let map, originMarker, destMarker, routeLayer;
function initMap() {
  map = L.map('map').setView([4.7110, -74.0721], 12);
  L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
    maxZoom: 19,
    attribution: '&copy; Carto & OpenStreetMap'
  }).addTo(map);
}
function clearRoute() {
  if (routeLayer) { routeLayer.remove(); routeLayer = null; }
  if (originMarker) { originMarker.remove(); originMarker = null; }
  if (destMarker) { destMarker.remove(); destMarker = null; }
  document.getElementById('origin-info').innerText = '—';
  document.getElementById('dest-info').innerText = '—';
  document.getElementById('result').innerHTML = '';
}
function formatCOP(n){ return '$ ' + n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.'); }
document.addEventListener('DOMContentLoaded', function(){
  initMap();
  const resultDiv = document.getElementById('result');
  const originInfo = document.getElementById('origin-info');
  const destInfo = document.getElementById('dest-info');
  const clearBtn = document.getElementById('clearBtn');
  let clickCount = 0;
  let origin = null, destination = null;
  map.on('click', function(e){
    clickCount++;
    if (clickCount === 1) {
      origin = { lat: e.latlng.lat, lon: e.latlng.lng };
      if (originMarker) originMarker.remove();
      originMarker = L.marker([origin.lat, origin.lon], { title: "Origen" }).addTo(map);
      originInfo.innerText = origin.lat.toFixed(5) + ', ' + origin.lon.toFixed(5);
    } else if (clickCount === 2) {
      destination = { lat: e.latlng.lat, lon: e.latlng.lng };
      if (destMarker) destMarker.remove();
      destMarker = L.marker([destination.lat, destination.lon], { title: "Destino" }).addTo(map);
      destInfo.innerText = destination.lat.toFixed(5) + ', ' + destination.lon.toFixed(5);
      resultDiv.innerHTML = 'Calculando...';
      fetch('/calcular', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ origin, destination })
      })
      .then(r => r.json().then(data => ({ ok: r.ok, data })))
      .then(({ ok, data }) => {
        if (!ok) { resultDiv.innerText = data.error || 'Error en el cálculo'; clickCount = 0; return; }
        const dist = data.distance_km;
        const dur = Math.round(data.duration_s / 60);
        const price = data.price;
        resultDiv.innerHTML = `<div><strong>Distancia:</strong> ${dist} km</div><div><strong>Duración estimada:</strong> ${dur} min</div><div><strong>Precio estimado:</strong> ${formatCOP(price)} COP</div>`;
        if (data.geometry) {
          if (routeLayer) routeLayer.remove();
          routeLayer = L.geoJSON(data.geometry, { style: { color: '#00E676', weight: 5, opacity: 0.95 } }).addTo(map);
          map.fitBounds(routeLayer.getBounds(), { padding: [20,20] });
        }
      })
      .catch(err => { resultDiv.innerText = 'Error: ' + err.message; })
      .finally(() => { clickCount = 0; });
    }
  });
  clearBtn.addEventListener('click', function(){ clearRoute(); clickCount = 0; });
});
